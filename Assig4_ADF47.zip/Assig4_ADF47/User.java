
/**
 * A user of the video engine.
 */
public interface User {

}
