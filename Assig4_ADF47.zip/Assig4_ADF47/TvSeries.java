
/**
 * A television series in the video engine.
 */
public interface TvSeries {

}
